﻿using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Custom;
using WebAPI.Models;
using WebAPI.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using WebAPI.Services.Contrato;
using WebAPI.Services.Implementacion;


namespace WebAPI.Controllers
{ 
[Route("api/[controller]")]
[Authorize]
[ApiController]

public class CompraController : Controller
    {

        private readonly ICompraService _compraServicio;


        public CompraController( ICompraService compraServicio)
        {
            _compraServicio = compraServicio;

        }


     

        [HttpPost]
        [Route("RegistrarCompra")]
        
         public async Task<IActionResult> RegistrarCompra(CompraCab objeto)
            {

             objeto.FecRegistro = DateTime.Now;

            var nuevaCompra = await _compraServicio.Add(objeto);

            
            if (nuevaCompra.Id_CompraCab != 0)
                    return StatusCode(StatusCodes.Status200OK, new { isSuccess = true });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false });
        }



    }
}

﻿using WebAPI.Custom;
using WebAPI.Models;
using WebAPI.Services.Contrato;
using WebAPI.Models.DTOs;
using Microsoft.EntityFrameworkCore;

namespace WebAPI.Services.Implementacion
{
    public class UsuarioService : IUsuarioService
    {
        private DbpruebaContext _dbContext;
        private readonly Utilidades _utilidades;
      


        public UsuarioService(DbpruebaContext dbContext, Utilidades utilidades)
        {
            _dbContext = dbContext;
            _utilidades = utilidades;
        }


        public async Task<Usuario> Add(UsuarioDTO modelo)
        {
            try
            {
                var modeloUsuario = new Usuario
                {
                    Nombre = modelo.Nombre,
                    Correo = modelo.Correo,
                    Clave = _utilidades.encriptarSHA256(modelo.Clave)
                };

                _dbContext.Usuarios.Add(modeloUsuario);
                await _dbContext.SaveChangesAsync();
                return modeloUsuario;

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        public async Task<Usuario> ValidaExiste(LoginDTO modelo)
        {
            try
            {
                var usuarioEncontrado = await _dbContext.Usuarios
                                                    .Where(u =>
                                                        u.Correo == modelo.Correo &&
                                                        u.Clave == _utilidades.encriptarSHA256(modelo.Clave)
                                                      ).FirstOrDefaultAsync();

                if (usuarioEncontrado == null)
                    return null;
                else
                    return usuarioEncontrado;


            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

       
    }
}
﻿using WebAPI.Models;
using WebAPI.Services.Contrato;

namespace WebAPI.Services.Implementacion
{
    public class VentaService : IVentaService
    {
        private DbpruebaContext _dbContext;

        public VentaService(DbpruebaContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<VentaCab> Add(VentaCab modelo)
        {
            try
            {
                _dbContext.Ventas.Add(modelo);
                await _dbContext.SaveChangesAsync();
                return modelo;

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

    }
}

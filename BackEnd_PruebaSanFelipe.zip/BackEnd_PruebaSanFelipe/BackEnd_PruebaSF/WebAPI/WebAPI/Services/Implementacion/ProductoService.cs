﻿using Microsoft.EntityFrameworkCore;
using WebAPI.Models;
using WebAPI.Services.Contrato;

namespace WebAPI.Services.Implementacion
{

    public class ProductoService : IProductoService
    {
        private DbpruebaContext _dbContext;

        public ProductoService(DbpruebaContext dbContext)
        {
            _dbContext = dbContext;
        }


        public async Task<Producto> Add(Producto modelo)
        {
            try
            {
                _dbContext.Productos.Add(modelo);
                await _dbContext.SaveChangesAsync();
                return modelo;  

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        public async Task<bool> Delete(Producto modelo)
        {
            try
            {
                _dbContext.Productos.Remove(modelo);
                await _dbContext.SaveChangesAsync();
                return true;

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        public async Task<Producto> Get(int idProducto)
        {
            try
            {
                Producto? encontrado = new Producto();
                encontrado = await _dbContext.Productos.Where(e => e.IdProducto == idProducto).FirstOrDefaultAsync();
               return encontrado;
            }
            catch (Exception ex)
            { throw ex; 
            
            }

        }

        public async Task<List<Producto>> GetList()
        {
            try
            { 
            List<Producto> lista = new List<Producto>();
                lista = await _dbContext.Productos.ToListAsync();   

                return lista;
            }
            catch(Exception ex)
            { throw ex; }



        }

        public async Task<bool> Update(Producto modelo)
        {
            try
            {
                _dbContext.Productos.Update(modelo);
                await _dbContext.SaveChangesAsync();
                return true;

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
    }
}

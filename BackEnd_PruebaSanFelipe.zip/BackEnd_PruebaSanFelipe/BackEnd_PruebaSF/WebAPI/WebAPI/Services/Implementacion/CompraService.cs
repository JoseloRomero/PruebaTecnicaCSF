﻿using Microsoft.EntityFrameworkCore;
using WebAPI.Models;
using WebAPI.Services.Contrato;

namespace WebAPI.Services.Implementacion
{
    public class CompraService:ICompraService
    {
        private DbpruebaContext _dbContext;

        public CompraService(DbpruebaContext dbContext)
        {
            _dbContext = dbContext;
        }


        public async Task<CompraCab> Add(CompraCab modelo)
        {
            try
            {
                _dbContext.Compras.Add(modelo);
                await _dbContext.SaveChangesAsync();
                return modelo;

            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

       
    }
}

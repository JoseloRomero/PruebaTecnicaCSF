﻿using WebAPI.Models;

namespace WebAPI.Services.Contrato
{
 

    public interface IVentaService
    {


        Task<VentaCab> Add(VentaCab modelo);



    }
}

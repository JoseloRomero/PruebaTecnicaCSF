﻿using WebAPI.Models;

namespace WebAPI.Services.Contrato
{
    public interface IProductoService
    {
        Task<List<Producto>> GetList(); 

        Task<Producto> Get(int idProducto);

        Task<Producto> Add(Producto modelo);

        Task<bool> Update(Producto modelo);
        
        Task<bool> Delete(Producto modelo);

    }
}

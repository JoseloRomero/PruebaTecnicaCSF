﻿using WebAPI.Models;
using WebAPI.Models.DTOs;

namespace WebAPI.Services.Contrato
{
    public interface IUsuarioService
    {

        Task<Usuario> Add(UsuarioDTO modelo);

        Task<Usuario> ValidaExiste(LoginDTO modelo);


    }
}

﻿using WebAPI.Models;

namespace WebAPI.Services.Contrato
{
    public interface ICompraService
    {
        

        Task<CompraCab> Add(CompraCab modelo);

      

    }
}

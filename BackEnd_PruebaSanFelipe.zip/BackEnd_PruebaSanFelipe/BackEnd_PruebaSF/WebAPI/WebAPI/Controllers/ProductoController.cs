﻿using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Custom;
using WebAPI.Models;
using WebAPI.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using WebAPI.Services.Contrato;
using WebAPI.Services.Implementacion;
//using AutoMapper;


namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly IProductoService _productoServicio;


        public ProductoController( IProductoService productoServicio)
        {
            _productoServicio = productoServicio;

        }

        [HttpGet]
        [Route("Lista")]
        public async Task<IActionResult> Lista()
        {

            var listaProducto = await _productoServicio.GetList();
           
            return StatusCode(StatusCodes.Status200OK, new { value = listaProducto });

            
        }

        [HttpPost]
        [Route("RegistrarProducto")]
        public async Task<IActionResult> Registrar(ProductoDTO _producto)
        {

            var _productonuevo = new Producto
            {
            Nombre = _producto.Nombre,
            Marca = _producto.Marca,
            Precio = _producto.Precio,
            FechaRegistro = DateTime.Now,
            NroLote = _producto.NroLote,
            Costo = _producto.Costo,
            PrecioVenta = _producto.PrecioVenta

            };

             var productonuevo = await _productoServicio.Add(_productonuevo);


            if (productonuevo.IdProducto != 0)
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = true });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false });
        }


    }
}

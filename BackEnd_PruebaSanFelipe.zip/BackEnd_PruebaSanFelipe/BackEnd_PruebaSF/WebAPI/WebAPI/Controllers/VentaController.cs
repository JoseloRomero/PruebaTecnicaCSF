﻿using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Custom;
using WebAPI.Models;
using WebAPI.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using WebAPI.Services.Contrato;
using WebAPI.Services.Implementacion;


namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]

    public class VentaController : Controller
    {

        private readonly IVentaService _ventaServicio;


        public VentaController(IVentaService ventaServicio)
        {
           _ventaServicio = ventaServicio;

        }




        [HttpPost]
        [Route("RegistrarVenta")]
        
        public async Task<IActionResult> RegistrarVenta(VentaCab objeto)
        {

            var nuevaCompra = await _ventaServicio.Add(objeto);


            if (nuevaCompra.Id_VentaCab != 0)
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = true });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false });
        }



    }
}


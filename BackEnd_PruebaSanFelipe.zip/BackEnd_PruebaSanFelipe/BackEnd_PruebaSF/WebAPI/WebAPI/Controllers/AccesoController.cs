﻿using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Custom;
using WebAPI.Models;
using WebAPI.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using WebAPI.Services.Contrato;


namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [AllowAnonymous]
    [ApiController]
    public class AccesoController : ControllerBase
    {
        private readonly Utilidades _utilidades;

        private readonly IUsuarioService _usuarioServicio;


        public AccesoController(IUsuarioService usuarioServicio, Utilidades utilidades)
        {
            _usuarioServicio = usuarioServicio;
            _utilidades = utilidades;   
        }



        [HttpPost]
        [Route("Registrarse")]
        public async Task<IActionResult> Registrarse(UsuarioDTO objeto)
        {

            
            var modeloUsuario = await _usuarioServicio.Add(objeto);

            if(modeloUsuario.IdUsuario != 0) 
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = true });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false });
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(LoginDTO objeto)
        {
           

            var usuarioEncontrado = await _usuarioServicio.ValidaExiste(objeto);


            if (usuarioEncontrado == null)
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = false, token = "" });
            else
                return StatusCode(StatusCodes.Status200OK, new { isSuccess = true, token = _utilidades.generarJWT(usuarioEncontrado)});
        }

        [HttpGet]
        [Route("ValidarToken")]
        public IActionResult ValidarToken([FromQuery] string token)
        {
           bool respuesta = _utilidades.validarToken(token);
           return StatusCode(StatusCodes.Status200OK, new { isSuccess = respuesta });
        }
    }
}

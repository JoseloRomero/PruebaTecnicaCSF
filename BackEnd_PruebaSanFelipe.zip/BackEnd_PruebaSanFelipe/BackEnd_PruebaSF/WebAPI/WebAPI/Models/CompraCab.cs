﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace WebAPI.Models
{
  
    public partial class CompraCab
    {
        public CompraCab()
        {
            DetalleCompras = new HashSet<CompraDet>();
        }

        public int Id_CompraCab { get; set; }
        public DateTime FecRegistro { get; set; }

        public decimal? SubTotal { get; set; }
        public decimal? Igv { get; set; }
        public decimal? Total { get; set; }

        public virtual ICollection<CompraDet> DetalleCompras { get; set; }


    }
}

﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace WebAPI.Models
{
  
    public partial class CompraDet
    {
        public int Id_CompraDet { get; set; }
        public int? Id_CompraCab { get; set; }
        public int? Id_producto { get; set; }
        public decimal? Precio { get; set; }
        public int? Cantidad { get; set; }
        public decimal? Sub_Total { get; set; }
        public decimal? Igv { get; set; }
        public decimal? Total { get; set; }

        public virtual CompraCab? IdCompraNavigation { get; set; }


    }
}

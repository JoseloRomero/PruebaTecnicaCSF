﻿namespace WebAPI.Models
{
   

    public  class VentaDet
    {
        public int Id_VentaDet { get; set; }
        public int? Id_VentaCab { get; set; }
        public int? Id_Producto { get; set; }
        public decimal? Precio { get; set; }
        public int? Cantidad { get; set; }
        public decimal? Sub_Total { get; set; }
        public decimal? Igv { get; set; }
        public decimal? Total { get; set; }

        public virtual VentaCab? IdCompraNavigation { get; set; }


    }
}

﻿namespace WebAPI.Models
{
    

    public class VentaCab
    {
        public VentaCab()
        {
            DetalleVentas = new HashSet<VentaDet>();
        }

        public int Id_VentaCab { get; set; }
        public DateTime FecRegistro { get; set; }

        public decimal? SubTotal { get; set; }
        public decimal? Igv { get; set; }
        public decimal? Total { get; set; }

        public virtual ICollection<VentaDet> DetalleVentas { get; set; }


    }
}

﻿namespace WebAPI.Models.DTOs
{

    public class CompraDTO
    {
        public CompraCab oCompra { get; set; }
        public List<CompraDet> oDetalleCompra { get; set; }

    }
}

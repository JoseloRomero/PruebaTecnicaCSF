﻿namespace WebAPI.Models.DTOs
{
    public class ProductoDTO
    {
        public int IdProducto { get; set; }

        public string? Nombre { get; set; }

        public string? Marca { get; set; }

        public decimal? Precio { get; set; }

        public int? NroLote { get; set; }
        public decimal? Costo { get; set; }
        public decimal? PrecioVenta { get; set; }
    }
}

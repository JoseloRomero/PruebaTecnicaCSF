﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebAPI.Models;

public partial class DbpruebaContext : DbContext
{
    public DbpruebaContext()
    {
    }

    public DbpruebaContext(DbContextOptions<DbpruebaContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Producto> Productos { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    public virtual DbSet<CompraCab> Compras { get; set; }

    public virtual DbSet<VentaCab> Ventas { get; set; }

    public virtual DbSet<CompraDet> DetalleCompras { get; set; }


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Producto>(entity =>
        {
            entity.HasKey(e => e.IdProducto).HasName("PK__Producto__09889210865E1F23");

            entity.ToTable("Producto");

            entity.Property(e => e.Marca)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Precio).HasColumnType("decimal(10, 2)");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.IdUsuario).HasName("PK__Usuario__5B65BF976629F431");

            entity.ToTable("Usuario");

            entity.Property(e => e.Clave)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Correo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false);
        });


        modelBuilder.Entity<CompraCab>(entity =>
        {
            entity.HasKey(e => e.Id_CompraCab)
                .HasName("PK__COMPRA__0A5CDB5CA1B55690");

            entity.ToTable("CompraCab");

          
            entity.Property(e => e.SubTotal).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Igv).HasColumnType("decimal(18, 2)");
           

            entity.Property(e => e.Total).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<CompraDet>(entity =>
        {
            entity.HasKey(e => e.Id_CompraDet)
                .HasName("PK__DETALLE___E046CCBBEE50023C");

            entity.ToTable("CompraDet");

            entity.Property(e => e.Precio).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Sub_Total).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Igv).HasColumnType("decimal(18, 2)");


            entity.Property(e => e.Total).HasColumnType("decimal(18, 2)");




            entity.HasOne(d => d.IdCompraNavigation)
                .WithMany(p => p.DetalleCompras)
                .HasForeignKey(d => d.Id_CompraCab)
                .HasConstraintName("FK_IdCompra");



        });

        modelBuilder.Entity<VentaCab>(entity =>
        {
            entity.HasKey(e => e.Id_VentaCab)
                .HasName("PK__VENTA__0A5CDB5CA1B55690");

            entity.ToTable("VentaCab");


            entity.Property(e => e.SubTotal).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Igv).HasColumnType("decimal(18, 2)");


            entity.Property(e => e.Total).HasColumnType("decimal(18, 2)");
        });

        modelBuilder.Entity<VentaDet>(entity =>
        {
            entity.HasKey(e => e.Id_VentaDet)
                .HasName("PK__DETALLEVENTA___E046CCBBEE50023C");

            entity.ToTable("VentaDet");

            entity.Property(e => e.Precio).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Sub_Total).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Igv).HasColumnType("decimal(18, 2)");


            entity.Property(e => e.Total).HasColumnType("decimal(18, 2)");




            entity.HasOne(d => d.IdCompraNavigation)
                .WithMany(p => p.DetalleVentas)
                .HasForeignKey(d => d.Id_VentaCab)
                .HasConstraintName("FK_IdVenta");



        });



        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

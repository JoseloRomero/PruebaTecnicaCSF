﻿using System;
using System.Collections.Generic;

namespace WebAPI.Models;

public partial class Producto
{
    public int IdProducto { get; set; }

    public string? Nombre { get; set; }

    public string? Marca { get; set; }

    public decimal? Precio { get; set; }

    public DateTime? FechaRegistro { get; set; }
    public int? NroLote { get; set; }
    public decimal? Costo { get; set; }
    public decimal? PrecioVenta { get; set; }


}
